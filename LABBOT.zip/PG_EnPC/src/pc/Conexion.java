package pc;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import pc.Parser;
import lejos.pc.comm.NXTCommLogListener;
import lejos.pc.comm.NXTConnector;

public class Conexion {
	
	private static final int TIME_OUT = 10000; //tiempo de espera m�ximo
	public static final int PUERTO = 9888; //puerto para la conexi�n
	private static ServerSocket socket;
	private static Socket s;
	private static Parser p;

	private static DataOutputStream dos = null;
	private static DataInputStream dis = null;
	private static DataOutputStream sDos = null;

	public static void main(String[] args) throws IOException {		
		NXTConnector conn = new NXTConnector();

		// Connect to any NXT over Bluetooth
		boolean connected = conn.connectTo("btspp://");

		if (!connected) {
			System.err.println("Failed to connect to any NXT");
			System.exit(1);
		}

		dos = new DataOutputStream(conn.getOutputStream());
		dis = new DataInputStream(conn.getInputStream());
		
		
		try {
			ArrayList<Integer> msg = recivirArreglo(); //
			try {
				//envia al robot el arreglo de n�meros y el numero de respuesta es guardado en num
				int num = enviar(msg);
//				sDos = new DataOutputStream(s.getOutputStream());
//				PrintWriter pw = new PrintWriter(s.getOutputStream(), true);
//				pw.println(num);
//				//sDos.writeInt(num);
//				//sDos.flush();
//				pw.flush();
//				Thread.sleep(250);
				
//				BufferedOutputStream bos = new BufferedOutputStream(s.getOutputStream());
//				bos.write(num);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				//Envias a RoBlock Hubo error en envio
			}
			System.out.println("Sending " + 1);
			//Envias a RoBLock que todo salio bien
			dos.flush();			

		} catch (IOException ioe) {
			System.out.println("IO Exception writing bytes:");
			System.out.println(ioe.getMessage());
		}

		try {
			System.out.println("Received " + dis.readInt());
		} catch (IOException ioe) {
			System.out.println("IO Exception reading bytes:");
			System.out.println(ioe.getMessage());
		}

		try {
			dis.close();
			dos.close();
			conn.close();
		} catch (IOException ioe) {
			System.out.println("IOException closing connection:");
			System.out.println(ioe.getMessage());
		}
	}
	
	//Metodo para conectarse y recivir el arreglo de ROBLOCK
	public static ArrayList<Integer> recivirArreglo() throws IOException {
		socket = new ServerSocket(PUERTO);
		System.out.println("Funcionando");
		ArrayList<Integer> resp = new ArrayList<Integer>();
		try {
			s = socket.accept();
			s.setSoTimeout(TIME_OUT);

			BufferedReader br = new BufferedReader (new InputStreamReader(s.getInputStream()));
			String linea = br.readLine();
			System.out.println("Ley� algo");
			System.out.println(linea);
			linea.replace("\n", "");
			String[] codigos = linea.split("[#$]"); //separa lo recivido por los caracteres #$
			
			//imprimir en consola como queda
			System.out.println(codigos.length);
			for(int i = 0; i < codigos.length; i++) {
				if(!codigos[i].equals("\n")) {
					System.out.println(codigos[i]);	
				}
			}
			
			//el arreylist codigos es parseado para que quede en un arreglo de solo n�meros 
			p = new Parser(codigos);
			resp = p.parsear();
			resp.add(900); //se agrega el n�mero 900 que indica fin

		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resp;
	}

	public static int enviar(ArrayList<Integer> msg ) throws IOException, InterruptedException {

		boolean salir = false;
		int respuesta = -1;
		int marcasContadas = 0;
		boolean esCondicional = false;
		
		for(int i = 0; i < msg.size() && !salir; i++) {
			int comando = msg.get(i);

			//Si el comando que le llega es un if debe revizar si la respuesta es exitosa pero no cumple
			if(comando == 200 || comando == 201) { 
				int siguiente = i+1;
				dos.writeInt(msg.get(siguiente));
				dos.flush();
				Thread.sleep(250);
				int resp = dis.readInt(); //espera la respuesta del robot
				if(resp == 2 ) { //si es exitosa ejecuta todo lo dentro al if
					boolean conCat = false;
					boolean end = false;
					int contadorCatenado = 0;
					int resta = 0;
					for(int j = i; j < msg.size() && !end; j++) {
						System.out.println("loop1");
						if (msg.get(j) == 200) { //reviza si hay un if dentro otro if
							conCat = true;
							contadorCatenado++;
						}
						else if (msg.get(j) == 202) { //si se termina un if lo reviza
							if(!conCat) {
								end = true;
							} else {
								resta = contadorCatenado - 1;
								if(resta <= 0) { //si ya se termino el if inicial o fue uno interno
									end = true;
									i=j;
								}								
							}
						}
					}
					continue;
				} else if (resp == -1) { //si la respuesta fue que se choc�, termina y se salta lo dentro al if
					salir = true;
					continue;
				} else { //si es positiva recorre lo dentro al if
					int pos = 0;
					int cont = 0;
					boolean terminar = false;
					boolean anidado = false;
					int contadorAnidado = 0;
					int resta = 0;
					ArrayList<Integer> lista = new ArrayList<Integer>();
					for(int k = i+1; k < msg.size() && !terminar; k++) { 
						System.out.println("loop2");
						if (msg.get(k) == 200) { //reviza si hay otro if dentro al if
							anidado = true;
							contadorAnidado++;
						}
						if (msg.get(k) == 202) {//reviza si termino el if inicial o fue uno dentro
							if(!anidado) {
								terminar = true;
							}
							resta=contadorAnidado-1;
							if(resta <= 0) {
								terminar = true;
							}
							pos = k-i-1;
						}
						cont = k;
						lista.add(msg.get(k));
					}			
					lista.remove(pos);
					int s = enviar(lista);
					if(s == 0 || s == 1 || s == 2) {
						i = cont; //se salta hasta el final del if
						continue;
					} else {
						salir = true;
						continue;
					}
				}
			} else if (comando == 202) { //si lee un 202 lo ignora
				continue;
			}
			//Si es un while reviza y determina hasta cuando se cumple la condici�n
			else if(comando == 100 || comando == 101) {
				int siguiente = i+1;
				dos.writeInt(msg.get(siguiente));
				dos.flush();
				Thread.sleep(250);
				int resp = dis.readInt();
				if(resp == 2) {
					boolean conCat = false;
					boolean end = false;
					int contadorCatenado = 0;
					int resta = 0;
					for(int j = i; j < msg.size() && !end; j++) { //reviza si hay dentro otros while igual que en el if
						if (msg.get(j) == 100) {
							conCat = true;
							contadorCatenado++;
						}
						if (msg.get(j) == 102) {
							if(!conCat) {
								end = true;
							}
							resta = contadorCatenado - 1;
							if(resta <= 0) {
								end = true;
								i=j;
							}
						}
					}
					continue;
				} else if (resp == 0 || resp == 1){
					int pos = 0;
					int cont = 0;
					boolean terminar = false;
					boolean anidado = false;
					int contadorAnidado = 0;
					int resta = 0;
					ArrayList<Integer> lista = new ArrayList<Integer>();
					for(int k = i+1; k < msg.size() && !terminar; k++) {
						System.out.println("loop2");
						if (msg.get(k) == 100) {
							anidado = true;
							contadorAnidado++;
						}
						if (msg.get(k) == 102) {
							if(!anidado) {
								terminar = true;
							}
							resta=contadorAnidado-1;
							if(resta <= 0) {
								terminar = true;
							}
							pos = k-i-1;
						}
						cont = k;
						lista.add(msg.get(k));
					}			
					lista.remove(pos);
					int s = enviar(lista);
					if(s == 0 || s == 1 || s == 2) {
						i = i-1;
						continue;
					} else {
						salir = true;
						continue;
					}
				} else { //si no cumple la condici�n salta todo
					salir = true;
					continue;
				}
			} else if (comando == 102) { //ignora el n�mero 102
				continue;
			} else if (comando == 300) {
				dos.writeInt(comando);
				dos.flush();
				Thread.sleep(250);
				int resp = dis.readInt();
				if(resp == -1) { //si esta mal la respuesta termina todo
					salir = true;
					continue;
				} else { //si esta bien sigue
					respuesta = resp;
				}
				
				dos.writeInt(301);
				dos.flush();
				Thread.sleep(250);
				marcasContadas = dis.readInt();
				esCondicional = true;
			}
			else { //si no es ningun caso de arriba lo envia al robot
				dos.writeInt(comando);
				dos.flush();
				Thread.sleep(250);
				int resp = dis.readInt();
				if(resp == -1) { //si la respuesta es mala termina todo
					salir = true;
					continue;
				} else { //si la respuesta es buena sigue sin problemas
					respuesta = resp;
				}
			}
		}

		if(salir) {
			respuesta = -1;
		}
		if(esCondicional) {
			if(marcasContadas == 3) {
				respuesta = 1;
			}
		}
		return respuesta;
	}

}
