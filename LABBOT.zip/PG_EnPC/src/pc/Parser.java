package pc;

import java.util.ArrayList;

import org.jfree.util.StringUtils;

public class Parser {

	private String[] listaCodigos;
	private ArrayList<Integer> comandos;

	public Parser (String[] codigo) {
		listaCodigos = codigo;
		comandos = new ArrayList<Integer>();
	}

	public ArrayList<Integer> parsear() {
		for(int i = 0; i < listaCodigos.length; i++) { //recorre la lista de numeros
			String s = listaCodigos[i];
			if(s != null) {
				if (s.contains("highlightBlock")) continue; //ignora highlightBlock
				if (s.contains("contar")) { //si contiene el metodo contar
					comandos.add(15); //agrega 15
					comandos.add(300); //agrega 300
					continue;
				}
				if (s.contains("move")) { //si contiene una acci�n de movimiento
					if(s.contains("-60")) {
						comandos.add(2);
						continue;
					} else if (s.contains("60")) {
						comandos.add(1);
						continue;
					} else if(s.contains("-30")) {
						comandos.add(8);
						continue;
					} else if(s.contains("-45")) {
						comandos.add(9);
						continue;
					} else if(s.contains("-60")) {
						comandos.add(10);
						continue;
					} else if(s.contains("-90")) {
						comandos.add(11);
						continue;
					} else if(s.contains("-180")) {
						comandos.add(12);
						continue;
					} else if(s.contains("30")) {
						comandos.add(3);
						continue;
					} else if(s.contains("45")) {
						comandos.add(4);
						continue;
					} else if(s.contains("60")) {
						comandos.add(5);
						continue;
					} else if(s.contains("90")) {
						comandos.add(6);
						continue;
					} else if(s.contains("180")) {
						comandos.add(7);
						continue;
					}
				} 
				if(s.contains("for")) { //si es un ciclo se pule la linea
					if(s.contains("<")) {
						s.replace(" ", "");
						String[] g = s.split("< ");
						String[] t = g[1].split(";");
						int x = Integer.parseInt(t[0]);
						boolean noMas = false;
						int contandoCiclosInternos = 0;
						int resta = 0;
						int cont = 0;
						int lineas = 0;
						for(int j = i; j < listaCodigos.length && !noMas; j++) { //se almacena en una lista todo lo dentro al for
							String k = listaCodigos[j];
							if(k.contains("{")) {
								lineas++;
								contandoCiclosInternos++;
							} else if(k.contains("}")) {
								resta++;
								lineas++;
								if(contandoCiclosInternos - resta == 0) {									
									noMas = true;
								}
							} else {
								lineas++;
								cont = j;
							}
						}
						String[] interno = new String[lineas-2];
						if(interno != null) {
							for(int k = i+1; k <= cont; k++) { //se recorre el interno y se parsea de nuevo lo de adentro
								interno[k-i-1] = listaCodigos[k];
							}
							Parser p = new Parser(interno);
							ArrayList<Integer> cry = p.parsear(); //lo parseado dentro se almacena qui
							for(int y = 0; y < x; y++) { //se recorre y se agrega a la lista final
								comandos.addAll(cry);
							}
							i=cont;	//se salta el for				
						}
						continue;
					}
					
				} 
				if(s.contains("while")) { //si es un while se pule y se reviza la condici�n
					if(s.contains("!")) { //esta negada?
						comandos.add(101);
						String[] g = s.split("\\(");
						if(g[2].contains("hayObstaculoAlFrente")) {
							comandos.add(17);
						}
						if(g[2].contains("hayMarcaAbajo")){
							comandos.add(16);
						}
						if(g[2].contains("hayMarcaAmarillaAbajo")){
							comandos.add(24);
						}
						if(g[2].contains("hayMarcaAzulAbajo")){
							comandos.add(25);
						}
						if(g[2].contains("hayMarcaRojaAbajo")){
							comandos.add(26);
						}
						if(g[2].contains("hayMarcaGrisAbajo")){
							comandos.add(27);
						}
						if(g[2].contains("hayMarcaVerdeAbajo")){
							comandos.add(28);
						}
						if(g[2].contains("hayMarcaNegraAbajo")){
							comandos.add(29);
						}
						boolean noMas = false;
						int contandoCiclosInternos = 0;
						int resta = 0;
						int cont = 0;
						int lineas = 0;
						for(int j = i; j < listaCodigos.length && !noMas; j++) { //se guarda una lista todo lo dentro al while
							String k = listaCodigos[j];
							if(k.contains("{")) {
								lineas++;
								contandoCiclosInternos++;
							} else if(k.contains("}")) {
								resta++;
								lineas++;
								if(contandoCiclosInternos - resta == 0) {									
									noMas = true;
								}
							} else {
								lineas++;
								cont = j;
							}
						}
						String[] interno = new String[lineas-2];
						if(interno != null) {
							for(int k = i+1; k <= cont; k++) { //se recorre el interno y se parsea de nuevo
								interno[k-i-1] = listaCodigos[k];
							}
							Parser p = new Parser(interno);
							ArrayList<Integer> cry = p.parsear();
							comandos.addAll(cry);
							i=cont; //se continua donde termina el while
							comandos.add(102);						
						}
						continue; 
					}else { //si no esta negado se hace lo mismo
						comandos.add(100);
						String[] g = s.split("\\(");
						if(g[1].contains("hayObstaculoAlFrente2")) {
							comandos.add(14);
						}
						if(g[1].contains("hayMarcaAbajo")){
							comandos.add(13);
						}
						if(g[1].contains("hayMarcaAmarillaAbajo")){
							comandos.add(18);
						}
						if(g[1].contains("hayMarcaAzulAbajo")){
							comandos.add(19);
						}
						if(g[1].contains("hayMarcaRojaAbajo")){
							comandos.add(20);
						}
						if(g[1].contains("hayMarcaGrisAbajo")){
							comandos.add(21);
						}
						if(g[1].contains("hayMarcaVerdeAbajo")){
							comandos.add(22);
						}
						if(g[1].contains("hayMarcaNegraAbajo")){
							comandos.add(23);
						}
						boolean noMas = false;
						int contandoCiclosInternos = 0;
						int resta = 0;
						int cont = 0;
						int lineas = 0;
						for(int j = i; j < listaCodigos.length && !noMas; j++) { //se guarda lo dentro al while en una lista
							String k = listaCodigos[j];
							if(k.contains("{")) {
								lineas++;
								contandoCiclosInternos++;
							} else if(k.contains("}")) {
								resta++;
								lineas++;
								if(contandoCiclosInternos - resta == 0) {									
									noMas = true;
								}
							} else {
								lineas++;
								cont = j;
							}
						}
						String[] interno = new String[lineas-2];
						if(interno != null) {
							for(int k = i+1; k <= cont; k++) { //se recorre la lista interna y se parsea
								interno[k-i-1] = listaCodigos[k];
							}
							Parser p = new Parser(interno);
							ArrayList<Integer> cry = p.parsear();
							comandos.addAll(cry);
							i=cont;
							comandos.add(102);						
						}
						continue;
					}
				}
				if(s.contains("if")) { //si es un if se pule y se mira cual es su condici�n
					if(s.contains("value")) continue;
					if(s.contains("!")) { //esta negado?
						comandos.add(201);
						String[] g = s.split("\\(");
						if(g[1].contains("hayObstaculoAlFrente2")) {
							comandos.add(14);
						}
						if(g[1].contains("hayMarcaAbajo")){
							comandos.add(16);
						}
						if(g[1].contains("hayMarcaAmarillaAbajo")){
							comandos.add(24);
						}
						if(g[1].contains("hayMarcaAzulAbajo")){
							comandos.add(25);
						}
						if(g[1].contains("hayMarcaRojaAbajo")){
							comandos.add(26);
						}
						if(g[1].contains("hayMarcaGrisAbajo")){
							comandos.add(27);
						}
						if(g[1].contains("hayMarcaVerdeAbajo")){
							comandos.add(28);
						}
						if(g[1].contains("hayMarcaNegraAbajo")){
							comandos.add(29);
						}
						boolean noMas = false;
						int contandoCiclosInternos = 0;
						int resta = 0;
						int cont = 0;
						int lineas = 0;
						for(int j = i; j < listaCodigos.length && !noMas; j++) { //se recorre y guarda todo dentro al if en una lista
							String k = listaCodigos[j];
							if(k.contains("{")) {
								lineas++;
								contandoCiclosInternos++;
							} else if(k.contains("}")) {
								resta++;
								lineas++;
								if(contandoCiclosInternos - resta == 0) {									
									noMas = true;
								}
							} else {
								lineas++;
								cont = j;
							}
						}
						String[] interno = new String[lineas-2];
						if(interno != null) {
							for(int k = i+1; k <= cont; k++) { //se recorre la lista interna y se parsea
								interno[k-i-1] = listaCodigos[k];
							}
							Parser p = new Parser(interno);
							ArrayList<Integer> cry = p.parsear();
							comandos.addAll(cry);
							i=cont; //se continua al final del if
							comandos.add(202);						
						}
						continue;
					} else { //si no est� negado se hace lo mismo
						comandos.add(200);
						String[] g = s.split("\\(");
						if(g[1].contains("hayObstaculoAlFrente2")) {
							comandos.add(14);
						}
						if(g[1].contains("hayMarcaAbajo")){
							comandos.add(13);
						}
						if(g[1].contains("hayMarcaAmarillaAbajo")){
							comandos.add(18);
						}
						if(g[1].contains("hayMarcaAzulAbajo")){
							comandos.add(19);
						}
						if(g[1].contains("hayMarcaRojaAbajo")){
							comandos.add(20);
						}
						if(g[1].contains("hayMarcaGrisAbajo")){
							comandos.add(21);
						}
						if(g[1].contains("hayMarcaVerdeAbajo")){
							comandos.add(22);
						}
						if(g[1].contains("hayMarcaNegraAbajo")){
							comandos.add(23);
						}
						boolean noMas = false;
						int contandoCiclosInternos = 0;
						int resta = 0;
						int cont = 0;
						int lineas = 0;
						for(int j = i; j < listaCodigos.length && !noMas; j++) {
							String k = listaCodigos[j];
							if(k.contains("{")) {
								lineas++;
								contandoCiclosInternos++;
							} else if(k.contains("}")) {
								resta++;
								lineas++;
								if(contandoCiclosInternos - resta == 0) {									
									noMas = true;
								}
							} else {
								lineas++;
								cont = j;
							}
						}
						String[] interno = new String[lineas-2];
						if(interno != null) {
							for(int k = i+1; k <= cont; k++) {
								interno[k-i-1] = listaCodigos[k];
							}
							Parser p = new Parser(interno);
							ArrayList<Integer> cry = p.parsear();
							comandos.addAll(cry);
							i=cont;
							comandos.add(202);						
						}
						continue;
					}
				}
				if(s.contains("function")) { //si es una funci�n se pule
					s.replace(" ", "");
					String[] g = s.split("function");
					String[] nF = g[1].split("\\{");
					String nomFunc = nF[0].replace(" ", "");
					boolean noMas = false;
					int contandoCiclosInternos = 0;
					int resta = 0;
					int cont = 0;
					int lineas = 0;
					for(int j = i; j < listaCodigos.length && !noMas; j++) { //se guarda todo dentro la funci�n en una lista
						String k = listaCodigos[j];
						if(k.contains("{")) {
							lineas++;
							contandoCiclosInternos++;
						} else if(k.contains("}")) {
							resta++;
							lineas++;
							if(contandoCiclosInternos - resta == 0) {									
								noMas = true;
							}
						} else {
							lineas++;
							cont = j;
						}
					}
					String[] interno = new String[lineas-2];
					if(interno != null) {
						for(int k = i+1; k <= cont; k++) { //se recorre la lista interna y se parsea
							interno[k-i-1] = listaCodigos[k];
						}
						Parser p = new Parser(interno);
						ArrayList<Integer> cry = p.parsear();
						ArrayList<Integer> cry2 = new ArrayList<Integer>();
						ArrayList<Integer> cry3 = new ArrayList<Integer>();
						String[] despues = new String[listaCodigos.length-lineas+2];
						int llegoAlFinal = 0;
						for(int n = cont; n < listaCodigos.length; n++) { //se recorre nueva mente por los compuestos dentro, sean for, while, if
							if(listaCodigos[n].contains(nomFunc)) {
								p = new Parser(despues);
								cry2 = p.parsear();
								cry3.addAll(cry2);
								cry3.addAll(cry);
								llegoAlFinal = n;
								for(int f = 0; f < despues.length; f++) {
									despues[f] = "";
								}
							} else {
								despues[n-cont] = listaCodigos[n];
							}
						}
						if(llegoAlFinal != listaCodigos.length) {
							ArrayList<String> xc = new ArrayList<String>();
							for(int z = llegoAlFinal; z < listaCodigos.length; z++) {
								xc.add(listaCodigos[z]);
							}
							String[] kl = new String[xc.size()];
							for(int z = 0; z < xc.size(); z++) {
								kl[z] = xc.get(z);
							}
							p = new Parser(kl);
							cry3.addAll(p.parsear()); //se agregan todos los n�meros a la lista final
						}
						comandos.addAll(cry3);
						i=listaCodigos.length;	//se continua al final de la funci�n					
					}
					continue;
				}
			}
		}
		//revizar en consola como va quedando
		System.out.println("Tama�o arreglo comandos: " + comandos.size()); 
		for(int i = 0; i < comandos.size() ; i++) {
			System.out.println("Comando" + "["+i+"]: " + comandos.get(i));
		}
		return comandos;
	}
	
}
