package robot;

import javax.microedition.sensor.UltrasonicChannelInfo;
import javax.xml.stream.events.Attribute;

import lejos.nxt.*;
import lejos.nxt.ColorSensor.Color;
import lejos.nxt.addon.ColorHTSensor;
import lejos.robotics.ColorDetector;
import lejos.robotics.LightDetector;
import lejos.robotics.navigation.DifferentialPilot;

public class Comandos {
	
	final static int FOWARD = 100;
	public static boolean choco = false;
	
	private int contador;
	
	private static DifferentialPilot bot;
	private TouchSensor ouch1;
	private TouchSensor ouch2;
	private UltrasonicSensor ojos;
	private ColorSensor infra;
	private LightSensor luz;
	
	//COLORES-----------------------
	private int piso;
	
	private int azul;
	private int azul1;
	
	private int amarillo;
	private int amarillo1;
	
	private int rojo;
	private int rojo1;
	
	private int gris;
	private int gris1;
	
	private int verde;
	private int verde1;
	
	private int negro;
	private int negro1;
	//-----------------------COLORES
	private boolean esCondicional;
	
	/**
	 * Constructor del metodo Comandos
	 * Aqu� se inicializan las variables necesarias para cada uno de los comandos de detecci�n y de movimiento
	 * Adem�s se inicializan los motores y los sensores
	 */
	public Comandos() {
		contador = 0;
		
		piso = 36; //36
		azul = 27; //27
		azul1 = 28; //28
		amarillo = 38;
		amarillo1 = 39;
		rojo = 40;
		rojo1 = 41;
		gris = 0;
		gris1 = 0;
		verde = 0;
		verde1 = 0;
		negro  = 21;
		negro1 = 20;
		
		esCondicional = false;
		
		//Se inicializa los motores indicandole los puertos de cada uno, adem�s de indicar en el primer
		//par�metro el ancho de las ruedas y el anchom de la v�a en el segundo
		bot = new DifferentialPilot(56, 108, Motor.B, Motor.C);
		//establecer la rotaci�n de la rueda, grados por segundo
		bot.setRotateSpeed(150);
		//en unidades de diametro de rueda por segundo
		bot.setTravelSpeed(150);
		
		//El volumen del robot
		Sound.setVolume(50);
		
		//Se inicializan los sensores de choque indicando los puertos
		ouch1 = new TouchSensor(SensorPort.S4);
		ouch2 = new TouchSensor(SensorPort.S2);
		
		//Se inicializa el censor ultras�nico
		ojos = new UltrasonicSensor(SensorPort.S3);
		ojos.capture();
		ojos.continuous();
		
		//Se inicializa el sensor infra-rojo indicandole el puerto
		infra = new ColorSensor(SensorPort.S1);
		//Se inicializa el sensor de luz indicandole el puerto
		luz = new LightSensor(SensorPort.S1);
		
	}
	
	//Si el robot se choca detiene toda ejecuci�n
	public void ouch() {
		
		Thread t = new Thread(new Runnable() {
			
			@Override
			public void run() {
				while (!choco) {
					if(ouch1.isPressed() || ouch2.isPressed()) {
						bot.stop();
						choco = true;
					}
				}
			}
		});
		choco = false;
		t.start();
	}
	
	//Con el sensor de ultrasonido se obtiene un n�mero que es la dstancia entre el robot y el obst�culo.
	public int teVeo() {
		return ojos.getDistance();
	}
	
	//se uso para realizar las pruebas de distancia.
	public void prueba() {
		while(!choco) {
			int x = ojos.getDistance();
			LCD.drawInt(x, 2, 2);
			LCD.refresh();
			
			if(ouch1.isPressed() || ouch2.isPressed()) {
				bot.stop();
				choco = true;
			}
		}
	}
	
	//
	// Matodos principales del robot para la ejecuci�n de las tareas en el escenario
	//
	
	/**
	 * Hace que el robot se desplace 310mm en adelante que equivale a una celda
	 */
	public int avanzarUnaCasilla() {
		bot.travel(300);
		if(!choco) {
			if(hayMarcaAbajo()) {
				return 1;
			}
			return 0;
		} else {
			return -1;
		}
	}
	
	/**
	 * Hace que el robot se desplace 310mm hacia atr�s que equivale a una celda
	 */
	public int retrocederUnaCasilla() {
		bot.travel(-300);
		if(!choco) {
			if(hayMarcaAbajo()) {
				return 1;
			}
			return 0;
		} else {
			return -1;
		}
	}
	
	/**
	 * Hace que el robot rote sobre su eje 30 grados a la izquierda.
	 */
	public int girar30ALaIzquierda() {
		bot.rotate(-30);
		if(!choco) {
			if(hayMarcaAbajo()) {
				return 1;
			}
			return 0;
		} else {
			return -1;
		}
	}
	
	/**
	 * Hace que el robot rote sobre su eje 45 grados a la izquierda.
	 */
	public int girar45ALaIzquierda() {
		bot.rotate(-45);
		if(!choco) {
			if(hayMarcaAbajo()) {
				return 1;
			}
			return 0;
		} else {
			return -1;
		}
	}
	
	/**
	 * Hace que el robot rote sobre su eje 60 grados a la izquierda.
	 */
	public int girar60ALaIzquierda() {
		bot.rotate(-60);
		if(!choco) {
			if(hayMarcaAbajo()) {
				return 1;
			}
			return 0;
		} else {
			return -1;
		}
	}
	
	/**
	 * Hace que el robot rote sobre su eje 90 grados a la izquierda.
	 */
	public int girar90ALaIzquierda() {
		bot.rotate(-90);
		if(!choco) {
			if(hayMarcaAbajo()) {
				return 1;
			}
			return 0;
		} else {
			return -1;
		}
	}
	
	/**
	 * Hace que el robot rote sobre su eje 180 grados a la izquierda.
	 */
	public int girar180ALaIzquierda() {
		bot.rotate(-180);
		if(!choco) {
			if(hayMarcaAbajo()) {
				return 1;
			}
			return 0;
		} else {
			return -1;
		}
	}
	
	/**
	 * Hace que el robot rote sobre su eje 30 grados a la derecha.
	 */	
	public int girar30ALaDerecha() {
		bot.rotate(30);
		if(!choco) {
			if(hayMarcaAbajo()) {
				return 1;
			}
			return 0;
		} else {
			return -1;
		}
	}
	
	/**
	 * Hace que el robot rote sobre su eje 45 grados a la derecha.
	 */	
	public int girar45ALaDerecha() {
		bot.rotate(45);
		if(!choco) {
			if(hayMarcaAbajo()) {
				return 1;
			}
			return 0;
		} else {
			return -1;
		}
	}
	
	/**
	 * Hace que el robot rote sobre su eje 60 grados a la derecha.
	 */	
	public int girar60ALaDerecha() {
		if(!choco) {
			if(hayMarcaAbajo()) {
				return 1;
			}
			return 0;
		} else {
			return -1;
		}
	}
	
	/**
	 * Hace que el robot rote sobre su eje 90 grados a la derecha.
	 */	
	public int girar90ALaDerecha() {
		bot.rotate(90);
		if(!choco) {
			if(hayMarcaAbajo()) {
				return 1;
			}
			return 0;
		} else {
			return -1;
		}
	}
	
	/**
	 * Hace que el robot rote sobre su eje 180 grados a la derecha.
	 */	
	public int girar180ALaDerecha() {
		bot.rotate(180);
		if(!choco) {
			if(hayMarcaAbajo()) {
				return 1;
			}
			return 0;
		} else {
			return -1;
		}
	}
	
	/**
	 * Usa el sensor ultras�nico para determinar si hay un obstaculo a una distancia menor de 60cm.
	 * Retorna true si hay un obstaculo y false si no
	 * @return true si esta a menos de 60 y false si esta a m�s de 60
	 */
	public boolean hayObstaculoFrente() {
		if(ojos.getDistance() <= 60) {
			return true;
		}
		return false;
	}
	
	/**
	 * Usa el sensor ultras�nico para determinar si hay un obstaculo a una distancia menor de 60cm.
	 * Retorna 1 si hay un obstaculo y esta en una marca, 0 si hay obstaculo y no esta en una marca
	 * 2 si el obstaculo esta m�s all� de 60cm
	 * @return 1,0 si esta menos de 60 y 2 si es mayor a 60
	 */
	public int hayObstaculoFrenteInt() {
		LCD.drawInt(ojos.getDistance(), 6, 6);
		if(!choco) {
			if(ojos.getDistance() <= 32) {
				if(hayMarcaAbajo()) {
					return 1;
				}
				return 0;
			} else {
				return 2;
			}
		}
		return -1;
	}
	
	/**
	 * Usa el sensor ultras�nico para determinar si hay un obstaculo a una distancia mayor de 60cm.
	 * Retorna 1 si hay un obstaculo y esta en una marca, 0 si hay obstaculo y no esta en una marca
	 * 2 si el obstaculo esta m�s all� de 60cm
	 * @return 1,0 si esta a m�s de 60 y 2 si es menor a 60
	 */
	public int noHayObstaculoFrenteInt() {
		LCD.drawInt(ojos.getDistance(), 6, 6);
		if(!choco) {
			if(ojos.getDistance() > 32) {
				if(hayMarcaAbajo()) {
					return 1;
				}
				return 0;
			} else {
				return 2;
			}
		}
		return -1;
	}
	
	/**
	 * Aumenta de uno un el contador de las marcas pisadas.
	 */
	public int contar() {
		contador++;
		if(!choco) {
			if(hayMarcaAbajo()) {
				LCD.drawInt(contador, 4, 4);
				return 1;
			}
			LCD.drawInt(contador, 4, 4);
			return 0;
		} else {
			LCD.drawInt(contador, 4, 4);
			return -1;
		}
	}
	
	/**
	 * Retorna el valor del contador.
	 * @return El valor del contador.
	 */
	public int darContador() {
		return contador;
	}
	
	/**
	 * Retorna true si hay marca abajo y false si no lo hay.
	 * @return True si hay marca y false si no hay.
	 */
	public boolean hayMarcaAbajo() {
		if(luz.readValue() != piso) {
			return true;
		}
		return false;
	}
	
	/**
	 * Retorna true si hay marca abajo y es amarilla. False si no lo hay o no es amarilla.
	 * @return True si hay marca amarilla y false si no.
	 */
	public boolean hayMarcaAmarilla() {
		if(luz.readValue() == 46) {
			return true;
		}
		return false;
	}
	
	/**
	 * Retorna true si hay marca abajo y es azul. False si no lo hay o no es azul.
	 * @return True si hay marca azul y false si no.
	 */
	public boolean hayMarcaAzul() {
		if(luz.readValue() == 30) {
			return true;
		}
		return false;
	}
	
	/**
	 * Retorna true si hay marca abajo y es negra. False si no lo hay o no es negra.
	 * @return True si hay marca negra y false si no.
	 */
	public boolean hayMarcaNegra() {
		if(luz.readValue() == 23) {
			return true;
		}
		return false;
	}
	
	/**
	 * Retorna true si hay marca abajo y es gris. False si no lo hay o no es gris.
	 * @return True si hay marca gris y false si no.
	 */
	public boolean hayMarcaGris() {
		if(luz.readValue() == 33) {
			return true;
		}
		return false;
	}
	
	/**
	 * Retorna 1 si hay marca abajo y 0 si no lo hay.
	 * @return 1 si hay marca y 0 si no hay.
	 */
	public int hayMarcaAbajoInt() {
		LCD.drawInt(luz.readValue(), 7, 7);
		if(!choco) {
			if(hayMarcaAbajo()) {
				return 1;
			}
			return 2;
		} else {
			return -1;
		}
	}
	
	/**
	 * Retorna 1 si hay marca amarilla abajo y 0 si no lo hay.
	 * @return 1 si hay marca y 0 si no hay.
	 */
	public int hayMarcaAmarillaAbajoInt() {
		LCD.drawInt(luz.readValue(), 7, 7);
		if(!choco) {
			if(luz.readValue() == amarillo || luz.readValue() == amarillo1) {
				return 1;
			}
			return 0;
		} else {
			return -1;
		}
	}
	
	/**
	 * Retorna 1 si hay marca azul abajo y 0 si no lo hay.
	 * @return 1 si hay marca y 0 si no hay.
	 */
	public int hayMarcaAzulAbajoInt() {
		LCD.drawInt(luz.readValue(), 7, 7);
		if(!choco) {
			if(luz.readValue() == azul || luz.readValue() == azul1) {
				return 1;
			}
			return 0;
		} else {
			return -1;
		}
	}
	
	/**
	 * Retorna 1 si hay marca roja abajo y 0 si no lo hay.
	 * @return 1 si hay marca y 0 si no hay.
	 */
	public int hayMarcaRojaAbajoInt() {
		LCD.drawInt(luz.readValue(), 7, 7);
		if(!choco) {
			if(luz.readValue() == rojo || luz.readValue() == rojo1) {
				return 1;
			}
			return 0;
		} else {
			return -1;
		}
	}
	
	/**
	 * Retorna 1 si hay marca gris abajo y 0 si no lo hay.
	 * @return 1 si hay marca y 0 si no hay.
	 */
	public int hayMarcaGrisAbajoInt() {
		LCD.drawInt(luz.readValue(), 7, 7);
		if(!choco) {
			if(luz.readValue() == gris || luz.readValue() == gris1) {
				return 1;
			}
			return 0;
		} else {
			return -1;
		}
	}
	
	/**
	 * Retorna 1 si hay marcaverde abajo y 0 si no lo hay.
	 * @return 1 si hay marca y 0 si no hay.
	 */
	public int hayMarcaVerdeAbajoInt() {
		LCD.drawInt(luz.readValue(), 7, 7);
		if(!choco) {
			if(luz.readValue() == verde || luz.readValue() == verde) {
				return 1;
			}
			return 0;
		} else {
			return -1;
		}
	}
	
	/**
	 * Retorna 1 si hay marc0 negra a abajo y 0 si no lo hay.
	 * @return 1 si hay marca y 0 si no hay.
	 */
	public int hayMarcaNegraAbajoInt() {
		LCD.drawInt(luz.readValue(), 7, 7);
		if(!choco) {
			if(luz.readValue() == negro || luz.readValue() == negro1) {
				return 1;
			}
			return 0;
		} else {
			return -1;
		}
	}
	
	/**
	 * Retorna 1 si no hay marca abajo y 0 si la hay.
	 * @return 1 si no hay marca y 0 si la hay.
	 */
	public int noHayMarcaAbajoInt() {
		LCD.drawInt(luz.readValue(), 7, 7);
		if(!choco) {
			if(!hayMarcaAbajo()) {
				return 0;
			}
			return 1;
		} else {
			return -1;
		}
	}
	
	/**
	 * Retorna 1 si no hay marca amarilla abajo y 0 si la hay.
	 * @return 1 si no hay marca y 0 si la hay.
	 */
	public int noHayMarcaAmarillaAbajoInt() {
		LCD.drawInt(luz.readValue(), 7, 7);
		if(!choco) {
			if(luz.readValue() != amarillo || luz.readValue() != amarillo1) {
				return 0;
			}
			return 1;
		} else {
			return -1;
		}
	}
	
	/**
	 * Retorna 1 si no hay marca azul abajo y 0 si la hay.
	 * @return 1 si no hay marca y 0 si la hay.
	 */
	public int noHayMarcaAzulAbajoInt() {
		LCD.drawInt(luz.readValue(), 7, 7);
		if(!choco) {
			if(luz.readValue() != azul || luz.readValue() != azul1) {
				return 0;
			}
			return 1;
		} else {
			return -1;
		}
	}
	
	/**
	 * Retorna 1 si no hay marca roja abajo y 0 si la hay.
	 * @return 1 si no hay marca y 0 si la hay.
	 */
	public int noHayMarcaRojaAbajoInt() {
		LCD.drawInt(luz.readValue(), 7, 7);
		if(!choco) {
			if(luz.readValue() != rojo || luz.readValue() != rojo1) {
				return 0;
			}
			return 1;
		} else {
			return -1;
		}
	}
	
	/**
	 * Retorna 1 si no hay marca gris abajo y 0 si la hay.
	 * @return 1 si no hay marca y 0 si la hay.
	 */
	public int noHayMarcaGrisAbajoInt() {
		LCD.drawInt(luz.readValue(), 7, 7);
		if(!choco) {
			if(luz.readValue() != gris || luz.readValue() != gris) {
				return 0;
			}
			return 1;
		} else {
			return -1;
		}
	}
	
	/**
	 * Retorna 1 si no hay marca verde abajo y 0 si la hay.
	 * @return 1 si no hay marca y 0 si la hay.
	 */
	public int noHayMarcaVerdeAbajoInt() {
		LCD.drawInt(luz.readValue(), 7, 7);
		if(!choco) {
			if(luz.readValue() != verde || luz.readValue() != verde) {
				return 0;
			}
			return 1;
		} else {
			return -1;
		}
	}
	
	/**
	 * Retorna 1 si no hay marca negra abajo y 0 si la hay.
	 * @return 1 si no hay marca y 0 si la hay.
	 */
	public int noHayMarcaNegraAbajoInt() {
		LCD.drawInt(luz.readValue(), 7, 7);
		if(!choco) {
			if(luz.readValue() != negro || luz.readValue() != negro1) {
				return 0;
			}
			return 1;
		} else {
			return -1;
		}
	}
	
	/**
	 * Cambia el estado de condicional a true y retorna 0 si no esta sobre una marca 1 lo contrario
	 * @return 1 si est� sobre una marca 0 si no lo est�
	 */
	public int cambiarACondicional() {
		esCondicional = true;
		if(!hayMarcaAbajo()) {
			return 0;
		}
		return 1;
	}
	
	/**
	 * Retorna el valor del contador
	 * @return el valor del contador
	 */
	public int preguntarContadorMarcas() {
		return contador;
	}
	
	/**
	 * Oblica a pensar al robot que se choc� y retorna 0
	 * @return 0
	 */
	public int hacerOuch() {
		choco = true;
		return 0;
	}
	
	/**
	 * Detiene el robot de toda ejecuci�n y retorna 0
	 * @return 0
	 */
	public int stop() {
		bot.stop();
		return 0;
	}
}

