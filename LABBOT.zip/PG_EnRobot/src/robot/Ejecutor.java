package robot;

import java.io.DataInputStream;
import java.io.DataOutputStream;

import lejos.nxt.LCD;
import lejos.nxt.comm.BTConnection;
import lejos.nxt.comm.Bluetooth;

public class Ejecutor {
	
	private static Comandos metodos;
	
	public static void main(String [] args)  throws Exception 
	{	
		
		metodos = new Comandos();
		
		//Indica el estado del robot
		String connected = "Connected";
        String waiting = "Waiting...";
        String closing = "Closing...";
        LCD.drawString(waiting,0,0);
        LCD.refresh();
        
        //Esperando la conexi�n bluetooth con el servidor, metodo bloqueante
        BTConnection btc = Bluetooth.waitForConnection();
        
        LCD.clear();
        LCD.drawString(connected,0,0);
        LCD.refresh();	
        
        //Inicializa los data
        DataInputStream dataIn = btc.openDataInputStream();
        DataOutputStream dataOut = btc.openDataOutputStream();
        
        int salir = 0;
        //Ejecuta el thret de chocarse
        metodos.ouch();
		while (salir != 900 && !metodos.choco) //El n�mero 900 indica el final de la lista
		{	
			
			int com = dataIn.readInt(); //Lee el n�mero de la lista
			salir = com;
			int resultado;
			switch(com) { //Mirar cual caso es el n�mero com
			case 1: //Si es uno avanza una casilla
				resultado = metodos.avanzarUnaCasilla();
				dataOut.writeInt(resultado);
				dataOut.flush(); //Necesario para que funcione, permite el envio
				Thread.sleep(100); //Necesario para que funcione, tiempo de espera
				break;
			case 2: //si es dos retrocede una casilla
				resultado = metodos.retrocederUnaCasilla();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 3: //si es tres gira 30 grados a la derecha
				resultado = metodos.girar30ALaDerecha();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 4: //si es cuatro gira 45 grados a la derecha
				resultado = metodos.girar45ALaDerecha();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 5: //si es cinco gira 60 grados a la derecha
				resultado = metodos.girar60ALaDerecha();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 6: //si es seis gira 90 grados a la derecha
				resultado = metodos.girar90ALaDerecha();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 7: //si es siete gira 180 grados a la derecha
				resultado = metodos.girar180ALaDerecha();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 8: //si es ocho gira 30 grados a la izquierda
				resultado = metodos.girar30ALaIzquierda();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 9: //si es nueve gira 45 grados a la izquierda
				resultado = metodos.girar45ALaIzquierda();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 10: //si es diez gira 60 grados a la izquierda
				resultado = metodos.girar60ALaIzquierda();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 11: //si es once gira 90 grados a la izquierda
				resultado = metodos.girar90ALaIzquierda();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 12: //si es doce gira 180 grados a la izquierda
				resultado = metodos.girar180ALaIzquierda();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 13: //si es trece reviza si hay una marca abajo
				resultado = metodos.hayMarcaAbajoInt();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 14: //si es catorce reviza si hay un obstaculo al frente 
				resultado = metodos.hayObstaculoFrenteInt();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 15: //si es quince cuenta
				resultado = metodos.contar();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 16: //si es diesiceis reviza si no hay una marca abajo
				resultado = metodos.noHayMarcaAbajoInt();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 17: // si es diecisiete reviza no haya obstaculo al frente
				resultado = metodos.noHayObstaculoFrenteInt();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 18: //si es dieciocho reviza si hay una marca abajo amarilla
				resultado = metodos.hayMarcaAmarillaAbajoInt();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 19: //si es quince reviza si hay una marca abajo azul
				resultado = metodos.hayMarcaAzulAbajoInt();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 20: //si es veinte reviza si hay una marca abajo roja
				resultado = metodos.hayMarcaRojaAbajoInt();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 21: //si es veintiuno reviza si hay una marca abajo gris
				resultado = metodos.hayMarcaGrisAbajoInt();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 22: //si es veintidos reviza si hay una marca abajo verde
				resultado = metodos.hayMarcaVerdeAbajoInt();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 23: //si es veintitres reviza si hay una marca abajo negra
				resultado = metodos.hayMarcaNegraAbajoInt();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 24: //si es veinticuatro reviza si no hay una marca abajo amarilla
				resultado = metodos.noHayMarcaAmarillaAbajoInt();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 25: //si es veinticinco reviza si no hay una marca abajo azul
				resultado = metodos.noHayMarcaAzulAbajoInt();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 26: //si es roja reviza si no hay una marca abajo roja
				resultado = metodos.noHayMarcaRojaAbajoInt();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 27: //si es vinticiete reviza si no hay una marca abajo gris
				resultado = metodos.noHayMarcaGrisAbajoInt();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 28: //si es veintiocho reviza si no hay una marca abajo verde
				resultado = metodos.noHayMarcaVerdeAbajoInt();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 29: //si es veintinueve reviza si no hay una marca abajo negra
				resultado = metodos.noHayMarcaNegraAbajoInt();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 100: //si es 100 pasa al siguiente
				break;
			case 101: //si es 101 pasa al siguiente
				break;
			case 200: //si es 200 pasa al siguiente
				break;
			case 201: //si es 201 pasa al siguiente
				break;
			case 300: //si es 300 cambia a condicional
				resultado = metodos.cambiarACondicional();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			case 301: //si es 301 pregunta cuantas marcas se han contado
				resultado = metodos.preguntarContadorMarcas();
				dataOut.writeInt(resultado);
				dataOut.flush();
				Thread.sleep(100);
				break;
			default:  //por defecto pasa al siguiente
				break;
			}
			
//			for(int i=0;i<100;i++) {
//				int n = dataIn.readInt();
//				LCD.drawInt(n,7,0,1);
//				LCD.refresh();
//				dataOut.writeInt(-n);
//				dataOut.flush();
//			}
			//metodos.hacerOuch();
		}
		dataIn.close(); //cierra el data in
		dataOut.close(); //cierra el data out
		Thread.sleep(100); // wait for data to drain
		LCD.clear(); //limpia la consola del robot
		LCD.drawString(closing,0,0); 
		LCD.refresh(); //refresca la consola
		btc.close(); //cierra la conexi�on bluetooth
		LCD.clear();
	}
	
}
